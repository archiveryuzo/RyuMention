package com.ryu.ryumention;

import org.bukkit.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns #RRGGBB (or &#RRGGBB) and &-codes in config text into real colors. */
public final class Colors {

    private static final Pattern HEX = Pattern.compile("&?#([A-Fa-f0-9]{6})");

    private Colors() {
    }

    public static String colorize(String text) {
        Matcher matcher = HEX.matcher(text);
        StringBuilder out = new StringBuilder();
        while (matcher.find()) {
            String color = net.md_5.bungee.api.ChatColor.of("#" + matcher.group(1)).toString();
            matcher.appendReplacement(out, Matcher.quoteReplacement(color));
        }
        matcher.appendTail(out);
        return ChatColor.translateAlternateColorCodes('&', out.toString());
    }
}
