package com.ryu.ryumention;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

/** Chat handling for plain Spigot servers (colors are written into the message text). */
public class LegacyChatListener implements Listener {

    private final MentionService service;

    public LegacyChatListener(MentionService service) {
        this.service = service;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        if (!sender.hasPermission("ryumention.use")) {
            return;
        }

        MentionService.Result result = service.parse(event.getMessage(), sender);
        if (result == null) {
            return;
        }

        StringBuilder out = new StringBuilder();
        for (MentionService.Part part : result.parts()) {
            if (part.mention() == null) {
                out.append(part.text());
            } else {
                // Remember the sender's own color so the text after the tag keeps it.
                String restore = ChatColor.getLastColors(out.toString());
                out.append(service.mentionLegacy(part.mention()));
                out.append(ChatColor.RESET).append(restore);
            }
        }
        event.setMessage(out.toString());

        service.finish(sender, result.tagged());
    }
}
