package com.ryu.ryumention;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MentionListener implements Listener {

    // A whole word that could be a Minecraft name (letters, numbers, underscore, up to 16 characters).
    // A leading @ is allowed and swallowed, so "@Steve" doesn't become "@@Steve".
    // The lookbehind/lookahead make sure we never match the middle of a longer word.
    private static final Pattern MENTION =
            Pattern.compile("(?<![A-Za-z0-9_@])@?([A-Za-z0-9_]{1,16})(?![A-Za-z0-9_])");

    private final RyuMention plugin;

    // Chat runs on a separate thread, so we keep our own list of online names
    // (lowercase name -> player id) instead of asking the server from that thread.
    private final Map<String, UUID> online = new ConcurrentHashMap<>();
    // When each player last tagged someone (for the cooldown).
    private final Map<UUID, Long> lastMention = new ConcurrentHashMap<>();

    public MentionListener(RyuMention plugin) {
        this.plugin = plugin;
    }

    /** Fills the name list for players already online (matters after a /reload or late enable). */
    public void loadOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            online.put(player.getName().toLowerCase(Locale.ROOT), player.getUniqueId());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        online.put(player.getName().toLowerCase(Locale.ROOT), player.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        online.remove(player.getName().toLowerCase(Locale.ROOT));
        lastMention.remove(player.getUniqueId());
    }

    // HIGH priority and ignoreCancelled: if another plugin mutes or blocks the message,
    // nobody gets tagged by it.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        if (!sender.hasPermission("ryumention.use")) {
            return;
        }

        String message = event.getMessage();

        FileConfiguration config = plugin.getConfig();
        int minNameLength = Math.max(1, config.getInt("min-name-length", 3));
        int maxMentions = Math.max(1, config.getInt("max-mentions-per-message", 3));
        boolean notifySelf = config.getBoolean("notify-self", false);
        String format = config.getString("mention-format", "#9D00FF@{player}");

        Matcher matcher = MENTION.matcher(message);
        StringBuilder out = new StringBuilder();
        Map<UUID, String> tagged = new LinkedHashMap<>();   // who to notify
        int count = 0;
        int last = 0;

        while (matcher.find() && count < maxMentions) {
            String word = matcher.group(1);
            if (word.length() < minNameLength) {
                continue; // very short words are skipped so normal chat doesn't light up
            }
            UUID targetId = online.get(word.toLowerCase(Locale.ROOT));
            if (targetId == null) {
                continue; // a word that isn't an online player's name stays as plain text
            }
            Player target = Bukkit.getPlayer(targetId);
            if (target == null) {
                continue;
            }

            // Text so far, plus the part before the tag. Used to restore the sender's own color afterwards.
            out.append(message, last, matcher.start());
            String restore = ChatColor.getLastColors(out.toString());

            out.append(Colors.colorize(format.replace("{player}", target.getName())));
            out.append(ChatColor.RESET).append(restore);

            last = matcher.end();
            count++;

            if (notifySelf || !targetId.equals(sender.getUniqueId())) {
                tagged.put(targetId, target.getName());
            }
        }

        if (count == 0) {
            return;
        }
        out.append(message.substring(last));
        event.setMessage(out.toString());

        if (tagged.isEmpty() || onCooldown(sender)) {
            return;
        }
        lastMention.put(sender.getUniqueId(), System.currentTimeMillis());

        // Titles and sounds must be sent from the main server thread, not the chat thread.
        String senderName = sender.getName();
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (UUID id : tagged.keySet()) {
                Player target = Bukkit.getPlayer(id);
                if (target != null) {
                    notify(target, senderName);
                }
            }
        });
    }

    private boolean onCooldown(Player sender) {
        long cooldownMillis = plugin.getConfig().getLong("cooldown-seconds", 3) * 1000L;
        Long previous = lastMention.get(sender.getUniqueId());
        return previous != null && System.currentTimeMillis() - previous < cooldownMillis;
    }

    /** What the tagged player sees and hears. */
    private void notify(Player target, String senderName) {
        FileConfiguration config = plugin.getConfig();

        if (config.getBoolean("notify.sound-enabled", true)) {
            playSound(target, config);
        }

        if (config.getBoolean("notify.title-enabled", true)) {
            String title = text("messages.title", senderName);
            String subtitle = text("messages.subtitle", senderName);
            target.sendTitle(title, subtitle,
                    config.getInt("notify.title-fade-in", 5),
                    config.getInt("notify.title-stay", 50),
                    config.getInt("notify.title-fade-out", 10));
        }

        if (config.getBoolean("notify.actionbar-enabled", true)) {
            target.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacyText(text("messages.actionbar", senderName)));
        }
    }

    private void playSound(Player target, FileConfiguration config) {
        String name = config.getString("notify.sound", "BLOCK_NOTE_BLOCK_PLING");
        try {
            Sound sound = Sound.valueOf(name.toUpperCase(Locale.ROOT));
            target.playSound(target.getLocation(), sound,
                    (float) config.getDouble("notify.volume", 1.0),
                    (float) config.getDouble("notify.pitch", 1.5));
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Unknown sound '" + name + "' in config.yml (notify.sound).");
        }
    }

    private String text(String path, String senderName) {
        return Colors.colorize(plugin.getConfig().getString(path, "").replace("{player}", senderName));
    }
}
