package com.ryu.ryumention;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Chat handling for Paper servers. Paper ignores colors that are put into a message the old way,
 * so here the message is rebuilt from chat components, which keep their colors.
 */
public class PaperChatListener implements Listener {

    private final MentionService service;

    public PaperChatListener(MentionService service) {
        this.service = service;
    }

    // HIGH priority and ignoreCancelled: if another plugin mutes or blocks the message,
    // nobody gets tagged by it.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player sender = event.getPlayer();
        if (!sender.hasPermission("ryumention.use")) {
            return;
        }

        String plain = PlainTextComponentSerializer.plainText().serialize(event.message());
        MentionService.Result result = service.parse(plain, sender);
        if (result == null) {
            return;
        }

        Component rebuilt = Component.empty();
        for (MentionService.Part part : result.parts()) {
            if (part.mention() == null) {
                rebuilt = rebuilt.append(Component.text(part.text()));
            } else {
                rebuilt = rebuilt.append(service.mentionComponent(part.mention()));
            }
        }
        event.message(rebuilt);

        service.finish(sender, result.tagged());
    }
}
