package com.ryu.ryumention;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class RyuMention extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        MentionService service = new MentionService(this);
        getServer().getPluginManager().registerEvents(service, this);
        service.loadOnlinePlayers();

        // Paper has its own chat event that keeps colors. Plain Spigot uses the older one.
        if (hasClass("io.papermc.paper.event.player.AsyncChatEvent")) {
            getServer().getPluginManager().registerEvents(new PaperChatListener(service), this);
            getLogger().info("Paper detected: using Paper chat events.");
        } else {
            getServer().getPluginManager().registerEvents(new LegacyChatListener(service), this);
            getLogger().info("Spigot detected: using legacy chat events.");
        }

        getCommand("ryumention").setExecutor(this);
        getLogger().info("RyuMention enabled.");
    }

    private boolean hasClass(String name) {
        try {
            Class.forName(name);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("ryumention.reload")) {
                sender.sendMessage(Colors.colorize(getConfig().getString("messages.no-permission", "&cNo permission.")));
                return true;
            }
            reloadConfig();
            sender.sendMessage(Colors.colorize(getConfig().getString("messages.reloaded", "&aReloaded.")));
            return true;
        }
        sender.sendMessage(Colors.colorize(getConfig().getString("messages.usage", "&cUsage: /ryumention reload")));
        return true;
    }
}
