package com.ryu.ryumention;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class RyuMention extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        MentionListener listener = new MentionListener(this);
        getServer().getPluginManager().registerEvents(listener, this);
        listener.loadOnlinePlayers();

        getCommand("ryumention").setExecutor(this);
        getLogger().info("RyuMention enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("ryumention.reload")) {
                sender.sendMessage(Colors.colorize(getConfig().getString("messages.no-permission", "&cNo permission.")));
                return true;
            }
            reloadConfig();
            sender.sendMessage(Colors.colorize(getConfig().getString("messages.reloaded", "&aReloaded.")));
            return true;
        }
        sender.sendMessage(Colors.colorize(getConfig().getString("messages.usage", "&cUsage: /ryumention reload")));
        return true;
    }
}
